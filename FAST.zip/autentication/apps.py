from django.apps import AppConfig


class AutenticationConfig(AppConfig):
    name = 'autentication'
