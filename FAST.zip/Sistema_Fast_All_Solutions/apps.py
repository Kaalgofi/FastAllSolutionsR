from django.apps import AppConfig


class SistemaFastAllSolutionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Sistema_Fast_All_Solutions'
